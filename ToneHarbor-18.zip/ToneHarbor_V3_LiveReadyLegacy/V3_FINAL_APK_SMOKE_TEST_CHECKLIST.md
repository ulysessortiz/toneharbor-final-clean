# ToneHarbor V3.0 Final APK Smoke Test Checklist

Test only the working app gates and V3 polish additions.

- Install APK
- Open ToneHarbor
- Complete or bypass onboarding
- Confirm Command Deck opens
- Test Quick Copy buttons
- Tap each bottom navigation tab
- Run Tone Check to result
- Confirm Use This Now card copies, saves, favorites
- Run Repair Builder to result
- Test Pressure Valve tool
- Save a repair
- Favorite a saved line
- Open Saved Repairs and confirm Top Steady Lines appears
- Delete one saved item
- Save Daily Ledger entry
- Confirm Weekly Insight appears
- Set PIN lock
- Close and reopen app
- Unlock with PIN
- Confirm no old/internal wording appears
