package com.toneharbor.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(5, 7, 9);
    private final int CARD = Color.rgb(18, 22, 26);
    private final int CARD2 = Color.rgb(24, 29, 34);
    private final int TEXT = Color.rgb(246, 239, 225);
    private final int MUTED = Color.rgb(178, 174, 166);
    private final int EMBER = Color.rgb(232, 166, 84);
    private final int EMBER2 = Color.rgb(197, 124, 47);
    private final int LINE = Color.rgb(80, 69, 55);
    private final int LINE_SOFT = Color.rgb(58, 52, 44);

    private SharedPreferences prefs;
    private LinearLayout root;
    private String currentScreen = "home";
    private String toneWhat = "", toneInside = "", toneLand = "";
    private String repairType = "", repairStyle = "";
    private String ledgerRelationship = "Not selected", ledgerHome = "Not selected", ledgerBody = "Not selected", ledgerMoney = "Not selected", ledgerPresence = "Not selected";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("toneharbor", MODE_PRIVATE);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        if (prefs.getBoolean("pinEnabled", false)) showUnlock();
        else if (!prefs.getBoolean("onboarded", false)) showWelcome();
        else showHome();
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }

    private void base() {
        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(BG);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(28), dp(20), dp(132));
        scroll.addView(root, new ScrollView.LayoutParams(ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));
        frame.addView(scroll, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(frame);
    }

    private TextView tv(String s, int sp, int color, int style) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setLetterSpacing(0.005f);
        t.setTextColor(color);
        t.setTypeface(Typeface.DEFAULT, style);
        t.setIncludeFontPadding(true);
        t.setLineSpacing(dp(2), 1.0f);
        t.setPadding(0, dp(3), 0, dp(3));
        return t;
    }

    private void space(int h) { Space s = new Space(this); root.addView(s, new LinearLayout.LayoutParams(1, dp(h))); }

    private GradientDrawable bg(int color, int strokeColor, int stroke, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radius));
        if (stroke > 0) g.setStroke(dp(stroke), strokeColor);
        return g;
    }

    private GradientDrawable primaryBg() {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{Color.rgb(252, 197, 112), EMBER2});
        g.setCornerRadius(dp(22));
        return g;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(18), dp(16), dp(18), dp(16));
        c.setBackground(bg(CARD, LINE_SOFT, 1, 24));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(7), 0, dp(9));
        root.addView(c, lp);
        return c;
    }

    private LinearLayout innerCard(LinearLayout parent) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(14), dp(12), dp(14), dp(12));
        c.setBackground(bg(CARD2, LINE_SOFT, 1, 18));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(6), 0, dp(6));
        parent.addView(c, lp);
        return c;
    }

    private Button btn(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(Color.rgb(24, 16, 8));
        b.setGravity(Gravity.CENTER);
        b.setIncludeFontPadding(false);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setBackground(primaryBg());
        b.setPadding(dp(8), dp(12), dp(8), dp(12));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(7), 0, dp(7));
        b.setLayoutParams(lp);
        return b;
    }

    private Button outline(String text) {
        Button b = btn(text);
        b.setTextColor(TEXT);
        b.setBackground(bg(CARD2, LINE, 1, 20));
        return b;
    }

    private Button compactButton(String text) {
        Button b = outline(text);
        b.setTextSize(14);
        b.setPadding(dp(8), dp(10), dp(8), dp(10));
        return b;
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    private void copy(String s) {
        ClipboardManager cm = (ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("ToneHarbor", s));
        toast("Copied.");
    }

    private void saveItem(String cat, String text) { saveItem(cat, text, false); }

    private void saveItem(String cat, String text, boolean favorite) {
        String old = prefs.getString("saved", "");
        String date = new SimpleDateFormat("MMM d, yyyy", Locale.US).format(new Date());
        String clean = text.replace("\n", " ").replace("|", "-");
        prefs.edit().putString("saved", old + cat + "|" + date + "|" + (favorite ? "1" : "0") + "|" + clean + "\n").apply();
        toast(favorite ? "Saved as a favorite." : "Saved to your Harbor.");
    }

    private void addTitle(String title, String sub) {
        root.addView(tv(title, 28, TEXT, Typeface.BOLD));
        if (sub != null && !sub.isEmpty()) root.addView(tv(sub, 15, MUTED, Typeface.NORMAL));
        space(10);
    }

    private void addMicroLabel(LinearLayout parent, String text) {
        TextView t = tv(text, 12, Color.rgb(255,217,167), Typeface.BOLD);
        t.setLetterSpacing(0.08f);
        parent.addView(t);
    }

    private void addDivider(LinearLayout parent) {
        View v = new View(this);
        v.setBackgroundColor(LINE_SOFT);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(1));
        lp.setMargins(0, dp(10), 0, dp(10));
        parent.addView(v, lp);
    }

    private LinearLayout miniPanel(LinearLayout parent, String title, String body) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(12), dp(10), dp(12), dp(10));
        c.setBackground(bg(Color.rgb(13, 17, 20), LINE_SOFT, 1, 16));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(5), 0, dp(5));
        parent.addView(c, lp);
        c.addView(tv(title, 14, Color.rgb(255,217,167), Typeface.BOLD));
        c.addView(tv(body, 14, TEXT, Typeface.NORMAL));
        return c;
    }

    private LinearLayout useThisNowCard(String title, String line) {
        LinearLayout c = card();
        addMicroLabel(c, "USE THIS NOW");
        c.addView(tv(title, 18, TEXT, Typeface.BOLD));
        c.addView(tv(line, 17, TEXT, Typeface.NORMAL));
        Button copy = btn("Copy Line");
        copy.setOnClickListener(v -> copy(line));
        c.addView(copy);
        Button save = outline("Save");
        save.setOnClickListener(v -> saveItem(title, line));
        c.addView(save);
        Button fav = outline("Favorite");
        fav.setOnClickListener(v -> saveItem("Favorite " + title, line, true));
        c.addView(fav);
        return c;
    }

    private void header(String title) {
        base();
        TextView h = tv("ToneHarbor", 13, Color.rgb(255, 217, 167), Typeface.BOLD);
        root.addView(h);
        addTitle(title, "Repair the moment before distance grows.");
    }

    private void nav() {
        space(8);
        LinearLayout n = new LinearLayout(this);
        n.setOrientation(LinearLayout.HORIZONTAL);
        n.setPadding(dp(4), dp(4), dp(4), dp(4));
        n.setBackground(bg(Color.rgb(10, 13, 15), LINE_SOFT, 1, 22));
        String[] tabs = {"Home", "Tone", "Repair", "Pressure", "Ledger"};
        for (String tab : tabs) {
            Button b = outline(tab);
            b.setTextSize(11);
            b.setPadding(dp(2), dp(9), dp(2), dp(9));
            b.setTextColor(isActiveTab(tab) ? Color.rgb(24, 16, 8) : TEXT);
            b.setBackground(isActiveTab(tab) ? primaryBg() : bg(CARD2, LINE_SOFT, 1, 18));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
            lp.setMargins(dp(3), dp(2), dp(3), dp(2));
            b.setLayoutParams(lp);
            b.setOnClickListener(v -> {
                if (tab.equals("Home")) showHome();
                else if (tab.equals("Tone")) showTone1();
                else if (tab.equals("Repair")) showRepair1();
                else if (tab.equals("Pressure")) showPressure();
                else showLedger();
            });
            n.addView(b);
        }
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(6), 0, dp(76));
        root.addView(n, lp);
    }

    private boolean isActiveTab(String tab) {
        if (tab.equals("Home")) return currentScreen.equals("home") || currentScreen.equals("before") || currentScreen.equals("saved") || currentScreen.equals("profile");
        if (tab.equals("Tone")) return currentScreen.equals("tone");
        if (tab.equals("Repair")) return currentScreen.equals("repair");
        if (tab.equals("Pressure")) return currentScreen.equals("pressure");
        return currentScreen.equals("ledger");
    }


    private void showUnlock() {
        currentScreen = "unlock";
        base();
        space(18);
        LinearLayout c = card();
        c.addView(tv("PRIVATE ACCESS", 14, Color.rgb(255,217,167), Typeface.BOLD));
        c.addView(tv("ToneHarbor", 34, TEXT, Typeface.BOLD));
        c.addView(tv("Enter your PIN to open your private Harbor.", 16, MUTED, Typeface.NORMAL));
        EditText pin = new EditText(this);
        pin.setHint("PIN");
        pin.setTextColor(TEXT);
        pin.setHintTextColor(MUTED);
        pin.setSingleLine(true);
        pin.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        pin.setBackground(bg(CARD2, LINE, 1, 16));
        pin.setPadding(dp(14), dp(12), dp(14), dp(12));
        c.addView(pin);
        Button open = btn("Unlock ToneHarbor");
        open.setOnClickListener(v -> {
            String saved = prefs.getString("pinCode", "");
            if (pin.getText().toString().equals(saved)) {
                if (!prefs.getBoolean("onboarded", false)) showWelcome(); else showHome();
            } else toast("PIN did not match.");
        });
        c.addView(open);
    }

    private void showPinSetup() {
        currentScreen = "profile";
        header("Private PIN Lock");
        LinearLayout c = card();
        c.addView(tv("Protect your saved repairs, ledger, and personal notes with a private PIN stored only on this device.", 17, TEXT, Typeface.NORMAL));
        EditText p1 = new EditText(this);
        p1.setHint("Create PIN");
        p1.setTextColor(TEXT); p1.setHintTextColor(MUTED); p1.setSingleLine(true);
        p1.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        p1.setBackground(bg(CARD2, LINE, 1, 16)); p1.setPadding(dp(14), dp(12), dp(14), dp(12));
        c.addView(p1);
        EditText p2 = new EditText(this);
        p2.setHint("Confirm PIN");
        p2.setTextColor(TEXT); p2.setHintTextColor(MUTED); p2.setSingleLine(true);
        p2.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        p2.setBackground(bg(CARD2, LINE, 1, 16)); p2.setPadding(dp(14), dp(12), dp(14), dp(12));
        c.addView(p2);
        Button save = btn("Enable PIN Lock");
        save.setOnClickListener(v -> {
            String a = p1.getText().toString();
            String b = p2.getText().toString();
            if (a.length() < 4) toast("Use at least 4 digits.");
            else if (!a.equals(b)) toast("PINs do not match.");
            else { prefs.edit().putBoolean("pinEnabled", true).putString("pinCode", a).apply(); toast("PIN lock enabled."); showProfile(); }
        });
        c.addView(save);
        Button cancel = outline("Back to Private Profile"); cancel.setOnClickListener(v -> showProfile()); c.addView(cancel);
        nav();
    }

    private void disablePin() {
        prefs.edit().putBoolean("pinEnabled", false).remove("pinCode").apply();
        toast("PIN lock removed.");
        showProfile();
    }

    private void showWelcome() {
        currentScreen = "welcome";
        base();
        space(18);
        LinearLayout c = card();
        c.addView(tv("PRIVATE REPAIR AND REGULATION", 14, Color.rgb(255,217,167), Typeface.BOLD));
        c.addView(tv("ToneHarbor", 38, TEXT, Typeface.BOLD));
        c.addView(tv("Repair the moment before distance grows.", 18, MUTED, Typeface.NORMAL));
        LinearLayout pill = innerCard(c);
        TextView p = tv("PRESSURE  →  TONE  →  REPAIR", 16, Color.rgb(255,217,167), Typeface.BOLD);
        p.setGravity(Gravity.CENTER);
        pill.addView(p);
        c.addView(tv("Built for the moments when pressure affects your tone, your words, or your next move.", 17, MUTED, Typeface.NORMAL));
        Button enter = btn("Enter ToneHarbor");
        enter.setOnClickListener(v -> showPromise());
        c.addView(enter);
        Button open = outline("Open Command Deck");
        open.setOnClickListener(v -> { prefs.edit().putBoolean("onboarded", true).apply(); showHome(); });
        c.addView(open);
        space(18);
    }

    private void showPromise() {
        currentScreen = "promise";
        header("Private Promise");
        LinearLayout c = card();
        c.addView(tv("No diagnosis. No judgment. No blame machine.", 22, TEXT, Typeface.BOLD));
        c.addView(tv("ToneHarbor helps you pause, understand possible impact, regulate pressure, and choose a steadier next move.", 18, TEXT, Typeface.NORMAL));
        c.addView(tv("It does not decide who is right. It does not replace therapy, legal advice, crisis care, or emergency support.", 15, MUTED, Typeface.NORMAL));
        Button next = btn("Continue");
        next.setOnClickListener(v -> showPattern());
        root.addView(next);
        Button command = outline("Open Command Deck");
        command.setOnClickListener(v -> { prefs.edit().putBoolean("onboarded", true).apply(); showHome(); });
        root.addView(command);
    }

    private void showPattern() {
        currentScreen = "pattern";
        header("Choose your pressure pattern");
        String[] opts = {"I get sharp when focused", "I shut down when overwhelmed", "I explain too much", "I get defensive after apologizing", "I rush people", "I avoid hard talks", "I get jealous or insecure", "I come home empty from work"};
        for (String o : opts) {
            Button b = outline(o);
            b.setOnClickListener(v -> { prefs.edit().putString("pattern", o).putBoolean("onboarded", true).apply(); showHome(); });
            root.addView(b);
        }
    }

    private void showHome() {
        currentScreen = "home";
        header("Command Deck");

        LinearLayout hero = card();
        addMicroLabel(hero, "PRIVATE REPAIR INTELLIGENCE");
        hero.addView(tv("Your next steady move, ready in seconds.", 20, TEXT, Typeface.BOLD));
        hero.addView(tv("Tone Landing Detector · Repair Builder · Pressure Valve · Daily Ledger", 15, TEXT, Typeface.BOLD));
        hero.addView(tv("Built for the moment when pressure, tone, or silence could become distance.", 14, MUTED, Typeface.NORMAL));

        LinearLayout best = card();
        addMicroLabel(best, "TODAY'S BEST NEXT MOVE");
        best.addView(tv(bestNextMove(), 19, TEXT, Typeface.BOLD));
        best.addView(tv("Copy a line fast, or choose your current state for a fuller reset.", 14, MUTED, Typeface.NORMAL));

        LinearLayout quick = card();
        quick.addView(tv("Quick Copy", 20, TEXT, Typeface.BOLD));
        quick.addView(tv("Use a steady line without entering a full flow.", 14, MUTED, Typeface.NORMAL));
        addCopyAction(quick, "Copy Focus Line", "I’m focused right now, not ignoring you. I’ll come back with better attention.");
        addCopyAction(quick, "Copy Need a Minute", "Give me one second. I want to respond better than my first reaction.");
        addCopyAction(quick, "Copy Tone Repair", "I’m sorry for how that landed. I want to repair it without defending first.");

        LinearLayout c = card();
        c.addView(tv("Where are you right now?", 20, TEXT, Typeface.BOLD));
        c.addView(tv("Tap a state for a quick read, a next move, and a copyable line.", 14, MUTED, Typeface.NORMAL));
        String[] states = {"Calm", "Pressured", "Irritated", "Shut Down", "Distracted", "Guilty", "About to React"};
        for (String state : states) {
            Button b = outline(state);
            b.setOnClickListener(v -> showStateReset(state));
            c.addView(b);
        }

        Button emergency = btn("Before It Breaks");
        emergency.setOnClickListener(v -> showBeforeItBreaks());
        root.addView(emergency);

        LinearLayout q = card();
        q.addView(tv("Core Tools", 20, TEXT, Typeface.BOLD));
        addAction(q, "Check My Tone", () -> showTone1());
        addAction(q, "Build a Repair", () -> showRepair1());
        addAction(q, "Use Pressure Valve", () -> showPressure());
        addAction(q, "Open Daily Ledger", () -> showLedger());

        LinearLayout line = card();
        line.addView(tv("Today’s Harbor Line", 18, Color.rgb(255,217,167), Typeface.BOLD));
        line.addView(tv(harborLine(), 18, TEXT, Typeface.BOLD));

        Button saved = outline("View Saved Repairs");
        saved.setOnClickListener(v -> showSaved());
        root.addView(saved);
        Button profile = outline("Private Profile");
        profile.setOnClickListener(v -> showProfile());
        root.addView(profile);
        nav();
    }

    private void addAction(LinearLayout parent, String label, final Action a) { Button b = compactButton(label); b.setOnClickListener(v -> a.run()); parent.addView(b); }

    private void addCopyAction(LinearLayout parent, String label, String line) {
        Button b = compactButton(label);
        b.setOnClickListener(v -> copy(line));
        parent.addView(b);
    }

    private String bestNextMove() {
        String[] moves = {
            "Repair before explaining.",
            "Take space without going cold.",
            "Copy the repair before pride edits it.",
            "Do not make the first impulse the final message.",
            "Say less. Own more. Return steady."
        };
        int i = (int)(System.currentTimeMillis() / 86400000L % moves.length);
        return moves[i];
    }

    interface Action { void run(); }

    private String responseForState(String s) {
        if (s.equals("Calm")) return "Steady is easier to protect before pressure rises.";
        if (s.equals("Pressured")) return "Pressure can be real without making the next move sharp.";
        if (s.equals("Irritated")) return "Slow the next sentence before it becomes damage.";
        if (s.equals("Shut Down")) return "Space is allowed. Coldness is not the only way to take it.";
        if (s.equals("Distracted")) return "Presence often begins with one honest pause.";
        if (s.equals("Guilty")) return "Guilt can become repair if you do not turn it into self-attack.";
        return "Do not let the first impulse become the final message.";
    }


    private void showStateReset(String state) {
        currentScreen = "before";
        header(state + " Reset");
        LinearLayout c = card();
        addMicroLabel(c, "QUICK READ");
        c.addView(tv(responseForState(state), 20, TEXT, Typeface.BOLD));
        addDivider(c);
        miniPanel(c, "What this may mean", stateMeaning(state));
        miniPanel(c, "Safer next move", stateNextMove(state));
        String line = stateCopyLine(state);
        useThisNowCard(state + " line", line);
        Button tone = outline("Check My Tone"); tone.setOnClickListener(v -> showTone1()); c.addView(tone);
        Button pressure = outline("Open Pressure Valve"); pressure.setOnClickListener(v -> showPressure()); c.addView(pressure);
        nav();
    }

    private String stateMeaning(String s) {
        if (s.equals("Calm")) return "This is the best time to protect the tone before pressure rises.";
        if (s.equals("Pressured")) return "Pressure may be tightening your voice, pace, or patience.";
        if (s.equals("Irritated")) return "The next sentence may carry more heat than the actual message needs.";
        if (s.equals("Shut Down")) return "Your system may need space, but silence can land as distance.";
        if (s.equals("Distracted")) return "Attention may be split, and split attention can sound like disinterest.";
        if (s.equals("Guilty")) return "Guilt can become repair if you keep it from turning into self-attack.";
        return "Impulse wants speed. Repair usually needs one slower sentence.";
    }

    private String stateNextMove(String s) {
        if (s.equals("Calm")) return "Use one soft check-in before the day gets louder.";
        if (s.equals("Pressured")) return "Name the pressure without making someone else carry it.";
        if (s.equals("Irritated")) return "Pause, lower the volume, and repair the edge before explaining.";
        if (s.equals("Shut Down")) return "Ask for space while clearly saying you are coming back.";
        if (s.equals("Distracted")) return "State that you are focused, not ignoring, and give a return point.";
        if (s.equals("Guilty")) return "Own one thing plainly. Do not pressure for instant forgiveness.";
        return "Do not send the first version. Choose repair over victory.";
    }

    private String stateCopyLine(String s) {
        if (s.equals("Calm")) return "I’m steady right now, and I want to keep the tone good between us.";
        if (s.equals("Pressured")) return "I’m under pressure, but I do not want to take it out on you.";
        if (s.equals("Irritated")) return "I’m irritated, so I’m going to slow down before I say this wrong.";
        if (s.equals("Shut Down")) return "I need a few minutes to settle. I’m not leaving the conversation.";
        if (s.equals("Distracted")) return "I’m focused right now, not ignoring you. I’ll come back with better attention.";
        if (s.equals("Guilty")) return "I can see I affected the moment. I want to repair it without defending first.";
        return "Give me one second. I want to respond better than my first reaction.";
    }

    private String harborLine() {
        String pat = prefs.getString("pattern", "");
        if (pat.contains("focused")) return "Focus can make your voice sound colder than your heart.";
        if (pat.contains("defensive")) return "Repair without defending first.";
        if (pat.contains("shut")) return "Take space without going cold.";
        if (pat.contains("home")) return "Do not make your first tone the leftover noise from the day.";
        String[] lines = {"Your state explains the tone. It does not erase the impact.", "Repair faster than pride can harden.", "Say less. Soften more. Own the landing.", "Pressure is real. The next move is still yours.", "Give space without going cold."};
        int i = (int)(System.currentTimeMillis() / 86400000L % lines.length);
        return lines[i];
    }

    private void showBeforeItBreaks() {
        currentScreen = "before";
        header("Before It Breaks");
        LinearLayout c = card();
        c.addView(tv("Pause line", 16, Color.rgb(255,217,167), Typeface.BOLD));
        String pause = "I want to answer better than my stress is letting me.";
        String next = "Give me one second. I’m not leaving the conversation. I’m trying not to make it worse.";
        c.addView(tv(pause, 22, TEXT, Typeface.BOLD));
        c.addView(tv("Drop your shoulders. Breathe out slowly.", 16, MUTED, Typeface.NORMAL));
        c.addView(tv(next, 18, TEXT, Typeface.NORMAL));
        useThisNowCard("Before It Breaks", next);
        Button pressure = outline("Open Pressure Valve"); pressure.setOnClickListener(v -> showPressure()); c.addView(pressure);
        Button repair = outline("Build a Repair"); repair.setOnClickListener(v -> showRepair1()); c.addView(repair);
        nav();
    }

    private void showTone1() { currentScreen = "tone"; header("Tone Check"); selectList("Step 1 of 3 · What happened?", new String[]{"My tone sounded rude", "I interrupted someone", "I snapped", "I got defensive", "I shut down", "I sounded cold", "I rushed the conversation", "I was focused and came off harsh", "Something else"}, s -> { toneWhat = s; showTone2(); }); }
    private void showTone2() { currentScreen = "tone"; header("Tone Check"); selectList("Step 2 of 3 · What was happening inside you?", new String[]{"I was focused", "I was overwhelmed", "I was tired", "I was anxious", "I was counting / calculating", "I felt accused", "I wanted space", "I was trying to solve it", "I do not know"}, s -> { toneInside = s; showTone3(); }); }
    private void showTone3() { currentScreen = "tone"; header("Tone Check"); selectList("Step 3 of 3 · How did it seem to land?", new String[]{"Dismissive", "Sharp", "Cold", "Impatient", "Controlling", "Unavailable", "Like I did not care", "I am not sure"}, s -> { toneLand = s; showToneResult(); }); }

    interface Pick { void set(String s); }
    private void selectList(String title, String[] opts, Pick pick) { LinearLayout c = card(); c.addView(tv(title, 20, TEXT, Typeface.BOLD)); for (String o : opts) { Button b = compactButton(o); b.setOnClickListener(v -> pick.set(o)); c.addView(b); } nav(); }

    private void showToneResult() {
        currentScreen = "tone";
        header("Tone Landing Detector");
        String repair = toneRepair();
        LinearLayout summary = card();
        addMicroLabel(summary, "TONE LANDING DETECTOR");
        summary.addView(tv("Intent may not have matched impact. Repair the landing before defending the intent.", 18, TEXT, Typeface.BOLD));
        summary.addView(tv("Path: " + toneWhat + " · " + toneInside + " · " + toneLand, 13, MUTED, Typeface.NORMAL));
        addResult("Possible Truth", toneTruth());
        addResult("Possible Impact", toneImpact());
        addResult("Responsibility Line", "Your state explains the tone. It does not erase the impact.");
        useThisNowCard("Tone repair", repair);
        addResult("Next Move", toneNextMove());
        Button calm = outline("I Need to Calm Down First"); calm.setOnClickListener(v -> showPressure()); root.addView(calm);
        Button again = outline("Start Over"); again.setOnClickListener(v -> showTone1()); root.addView(again);
        nav();
    }

    private String safeLower(String s) { return (s == null || s.length() == 0) ? "unclear" : s.toLowerCase(Locale.US); }
    private void addResult(String label, String text) { LinearLayout c = card(); c.addView(tv(label, 16, Color.rgb(255,217,167), Typeface.BOLD)); c.addView(tv(text, 18, TEXT, Typeface.NORMAL)); }

    private String toneTruth() {
        if (toneInside.contains("counting") || toneInside.contains("focused") || toneWhat.contains("focused")) return "You may have been protecting concentration, not trying to dismiss anyone. The repair still begins with how the interruption or sharpness landed.";
        if (toneInside.contains("accused") || toneWhat.contains("defensive")) return "You may have felt accused and moved into protection mode. That explains the defense, but repair works better when impact comes before explanation.";
        if (toneWhat.contains("shut") || toneInside.contains("space")) return "You may have needed space because your system was overloaded. Space is allowed, but going cold can still feel like punishment.";
        if (toneInside.contains("tired") || toneWhat.contains("cold")) return "You may have been tired, drained, or low on capacity. Tired tone can still land as distance.";
        if (toneInside.contains("solve") || toneWhat.contains("rushed")) return "You may have been trying to solve the problem quickly. Speed can still land as impatience or control.";
        return "You may have been overloaded, focused, hurt, or defensive. That can explain the reaction without making the impact disappear.";
    }

    private String toneImpact() {
        String land = safeLower(toneLand);
        if (toneLand.contains("not care")) return "It may have landed like you did not care, even if you were actually overwhelmed, focused, or unsure how to respond.";
        if (toneLand.contains("Controlling")) return "It may have landed as controlling because the other person experienced pressure, interruption, or urgency instead of collaboration.";
        if (toneLand.contains("Unavailable")) return "It may have landed as emotional distance or unavailability, especially if you went quiet or tried to exit without a repair line.";
        return "It may have landed as " + land + ", distance, or dismissal. This does not prove intent, but it gives you a safer repair path.";
    }

    private String toneNextMove() {
        if (toneWhat.contains("interrupted") || toneInside.contains("counting")) return "Repair the interruption first. Then explain the focus briefly. Do not argue that you were only counting.";
        if (toneWhat.contains("defensive")) return "Acknowledge the defensiveness first. One sentence is stronger than a long courtroom defense.";
        if (toneWhat.contains("shut") || toneInside.contains("space")) return "Give space with a return signal. Say when you are coming back so space does not become coldness.";
        return "Offer repair once. Give space without punishing. Do not argue your intent first.";
    }

    private String toneRepair() {
        if (toneInside.contains("counting") || toneInside.contains("focused") || toneWhat.contains("focused")) return "I’m sorry. I got locked into what I was doing and sounded sharper than I meant to. I was not trying to dismiss you, but I understand how it landed.";
        if (toneWhat.contains("interrupted")) return "I’m sorry I interrupted you. I reacted too abruptly, and I can see how that could feel dismissive.";
        if (toneWhat.contains("defensive") || toneInside.contains("accused")) return "I’m sorry I got defensive. I moved too fast into explaining myself instead of hearing how it landed.";
        if (toneWhat.contains("shut") || toneInside.contains("space")) return "I’m sorry I went quiet in a way that felt cold. I needed space, but I should have said that without disappearing.";
        if (toneWhat.contains("cold") || toneInside.contains("tired")) return "I’m sorry I sounded cold. I was tired, but I still want to speak in a way that feels caring.";
        if (toneWhat.contains("rushed") || toneInside.contains("solve")) return "I’m sorry I rushed the conversation. I was trying to solve it, but I can see how that may have felt impatient.";
        return "I’m sorry for how that landed. I may have been pressured, but I still want to own the impact and speak better.";
    }

    private void showRepair1() { currentScreen = "repair"; header("Repair Builder"); selectList("What needs repair?", new String[]{"My tone", "My silence", "My defensiveness", "My impatience", "My jealousy / insecurity", "My distraction", "A broken promise", "Stress spillover", "I interrupted", "I sounded cold", "I apologized poorly", "I needed space badly"}, s -> { repairType = s; showRepair2(); }); }
    private void showRepair2() { currentScreen = "repair"; header("Repair Builder"); selectList("What style do you need?", new String[]{"Short and simple", "Warm and accountable", "After they left upset", "After I made it worse", "Give space without disappearing", "Focused and abrupt", "Defensive after apology", "After work spillover"}, s -> { repairStyle = s; showRepairResult(); }); }

    private void showRepairResult() {
        currentScreen = "repair";
        header("Repair Output");
        String msg = repairMsg();
        LinearLayout summary = card();
        addMicroLabel(summary, "REPAIR BUILDER");
        summary.addView(tv("One accountable sentence is stronger than a long defense.", 18, TEXT, Typeface.BOLD));
        summary.addView(tv("Repair path: " + repairType + " · " + repairStyle, 13, MUTED, Typeface.NORMAL));
        useThisNowCard("Repair", msg);
        addResult("Do Not Add", "Do not add: ‘but I didn’t mean it,’ ‘you always take it wrong,’ ‘I already apologized,’ or ‘fine, forget it.’");
        addResult("Better Next Action", "Give space without going cold. Repair the landing before explaining the intent.");
        Button again = outline("Build Another"); again.setOnClickListener(v -> showRepair1()); root.addView(again);
        nav();
    }

    private String repairMsg() {
        if (repairStyle.contains("Focused") || repairType.contains("interrupted")) return "I’m sorry I stopped the moment abruptly. I was focused, but I still should have made room for you instead of sounding sharp.";
        if (repairStyle.contains("Defensive") || repairType.contains("defensiveness")) return "You were telling me how it landed, and I got defensive. I’m sorry. I want to understand the impact before I explain myself.";
        if (repairStyle.contains("work") || repairType.contains("Stress")) return "I’m sorry my pressure spilled into my tone. Work may explain why I was tense, but it does not make it fair to bring that edge into the room.";
        if (repairType.contains("cold")) return "I’m sorry I sounded cold. I care more than my tone showed, and I want to repair that.";
        if (repairType.contains("apologized")) return "I’m sorry my apology turned into more defense. Let me slow down and own the part that landed badly.";
        if (repairStyle.contains("left")) return "I’m sorry today turned heavy. I can see how my tone made it harder to receive what I meant. I’ll give you space, and I’m here when you’re ready.";
        if (repairStyle.contains("worse")) return "I’m sorry. I made it worse after the first moment. I do not want to defend that. I want to own it and do better from here.";
        if (repairStyle.contains("space") || repairType.contains("space")) return "I need a few minutes to settle so I do not speak worse. I’m not leaving the conversation.";
        if (repairStyle.contains("Warm")) return "I’m sorry for my " + repairType.toLowerCase(Locale.US) + ". I was under pressure, but I still should have handled it softer and clearer.";
        return "I’m sorry for how I handled that. I should have spoken softer.";
    }

    private void showPressure() {
        currentScreen = "pressure";
        header("Pressure Valve");
        String[] tools = {"Do Not Send That Yet", "60-Second Reset", "Tone Softener", "Focus Mode", "I Need Space Without Punishing", "After Work Decompression"};
        for (String tool : tools) { Button b = compactButton(tool); b.setOnClickListener(v -> showPressureTool(tool)); root.addView(b); }
        nav();
    }

    private void showPressureTool(String tool) {
        currentScreen = "pressure";
        header(tool);
        LinearLayout c = card();
        String text;
        if (tool.startsWith("Do")) text = "Wait 60 seconds. Rewrite for repair, not victory. Safer line: I want to say this better. I’m upset, but I do not want to make it worse.";
        else if (tool.startsWith("60")) text = "Unclench your jaw. Drop your shoulders. Breathe out longer than you breathe in. Say: I can repair without defending first. Choose one next move.";
        else if (tool.startsWith("Tone")) text = "Instead of ‘Wait,’ say: Give me one second, I want to hear you. Instead of ‘I’m busy,’ say: I’m in the middle of something, but you matter.";
        else if (tool.startsWith("Focus")) text = "Give me one second. I’m focused, not ignoring you. I want to hear you. I need one minute to finish this safely.";
        else if (tool.startsWith("I Need")) text = "I need a few minutes to settle so I do not speak worse. I’m not leaving the conversation.";
        else text = "I’m tired, but I’m glad to be home. Give me a minute to land.";
        c.addView(tv(text, 18, TEXT, Typeface.NORMAL));
        LinearLayout next = innerCard(c);
        next.addView(tv("Choose one next move", 16, Color.rgb(255,217,167), Typeface.BOLD));
        next.addView(tv("Apologize · Ask one calm question · Give space · Do one helpful action · Stop texting · Return in 10 minutes", 16, TEXT, Typeface.NORMAL));
        useThisNowCard("Pressure line", text);
        nav();
    }

    private void showLedger() {
        currentScreen = "ledger";
        header("Daily Ledger");
        addWeeklySummary();
        LinearLayout c = card();
        c.addView(tv("Private accountability without shame.", 18, TEXT, Typeface.BOLD));
        addLedgerGroup(c, "Relationship", "Did I repair anything I damaged today?", new String[]{"Yes", "Not needed", "I avoided it", "I made it worse", "I need help repairing"}, "relationship");
        addLedgerGroup(c, "Home", "What is one thing I handled without being asked?", new String[]{"Cleaned something", "Paid / checked something", "Followed up", "Helped partner", "Planned food", "Was present", "Not today"}, "home");
        addLedgerGroup(c, "Body", "Did I treat my body like it has to carry me tomorrow?", new String[]{"Water", "Food", "Sleep", "Walk", "Medication", "Less nicotine / alcohol", "Not today"}, "body");
        addLedgerGroup(c, "Money", "Did I face one money truth today?", new String[]{"Counted", "Paid", "Planned", "Asked", "Avoided", "Not needed"}, "money");
        addLedgerGroup(c, "Presence", "Who needed me present today?", new String[]{"Partner", "Child", "Family", "Friend", "Myself", "Pet", "No one today"}, "presence");
        EditText note = new EditText(this);
        note.setHint("One honest line");
        note.setTextColor(TEXT); note.setHintTextColor(MUTED); note.setSingleLine(false); note.setMinLines(2); note.setBackground(bg(CARD2, LINE, 1, 16));
        c.addView(note);
        Button save = btn("Save Today’s Ledger");
        save.setOnClickListener(v -> {
            String old = prefs.getString("ledger", "");
            String date = new SimpleDateFormat("MMM d, yyyy h:mm a", Locale.US).format(new Date());
            String row = date + " | Relationship: " + ledgerRelationship + " | Home: " + ledgerHome + " | Body: " + ledgerBody + " | Money: " + ledgerMoney + " | Presence: " + ledgerPresence + " | Note: " + note.getText().toString() + "\n";
            prefs.edit().putString("ledger", old + row).apply();
            toast("Saved. You faced today honestly.");
        });
        c.addView(save);
        Button saved = outline("View Saved Repairs"); saved.setOnClickListener(v -> showSaved()); root.addView(saved);
        nav();
    }

    private void addWeeklySummary() {
        LinearLayout s = card();
        s.addView(tv("Weekly Summary", 18, Color.rgb(255,217,167), Typeface.BOLD));
        int ledgerCount = countLines(prefs.getString("ledger", ""));
        int savedCount = countLines(prefs.getString("saved", ""));
        int favCount = countFavorites();
        s.addView(tv("Ledger entries: " + ledgerCount + "\nSaved lines: " + savedCount + "\nFavorites: " + favCount, 16, TEXT, Typeface.NORMAL));
        s.addView(tv(weeklyInsight(ledgerCount, savedCount, favCount), 16, TEXT, Typeface.BOLD));
        s.addView(tv("No scores. No shame. Just a private snapshot of repair and responsibility.", 14, MUTED, Typeface.NORMAL));
    }

    private String weeklyInsight(int ledgerCount, int savedCount, int favCount) {
        if (ledgerCount == 0 && savedCount == 0) return "Insight: Start with one honest line or one saved repair.";
        if (favCount > 0) return "Insight: You are building a small library of steady lines.";
        if (ledgerCount > savedCount) return "Insight: You are facing the day. Save any line that helped.";
        if (savedCount > 0) return "Insight: Useful repair language is becoming easier to find.";
        return "Insight: One steady action is enough to begin.";
    }

    private int countLines(String data) {
        if (data == null || data.trim().isEmpty()) return 0;
        int count = 0;
        for (String line : data.split("\n")) if (!line.trim().isEmpty()) count++;
        return count;
    }

    private int countFavorites() {
        String data = prefs.getString("saved", "");
        int count = 0;
        for (String line : data.split("\n")) {
            String[] parts = line.split("\\|", 4);
            if (parts.length >= 4 && parts[2].equals("1")) count++;
        }
        return count;
    }

    private void addLedgerGroup(LinearLayout parent, String title, String prompt, String[] opts, String key) {
        LinearLayout box = innerCard(parent);
        box.addView(tv(title, 16, Color.rgb(255,217,167), Typeface.BOLD));
        box.addView(tv(prompt, 16, TEXT, Typeface.NORMAL));
        for (String opt : opts) {
            Button b = compactButton(opt);
            b.setOnClickListener(v -> { setLedger(key, opt); toast(title + ": " + opt); });
            box.addView(b);
        }
    }

    private void setLedger(String key, String value) {
        if (key.equals("relationship")) ledgerRelationship = value;
        else if (key.equals("home")) ledgerHome = value;
        else if (key.equals("body")) ledgerBody = value;
        else if (key.equals("money")) ledgerMoney = value;
        else ledgerPresence = value;
    }

    private void addTopSteadyLines(String data) {
        LinearLayout top = card();
        addMicroLabel(top, "TOP STEADY LINES");
        int shown = 0;
        for (String line : data.split("\n")) {
            if (line.trim().isEmpty()) continue;
            String[] parts = line.split("\\|", 4);
            if (parts.length >= 4 && parts[2].equals("1")) {
                miniPanel(top, "Favorite", parts[3]);
                shown++;
                if (shown >= 3) break;
            }
        }
        if (shown == 0) {
            miniPanel(top, "Start here", "Save or favorite a line that helps, then it will appear here.");
        }
    }

    private void showSaved() {
        currentScreen = "saved";
        header("Saved Repairs");
        String data = prefs.getString("saved", "");
        addTopSteadyLines(data);
        if (data.trim().isEmpty()) addResult("No saved repairs yet", "When a line helps, save it here so steadiness is easier to find later.");
        else {
            String[] lines = data.split("\n");
            for (int i = 0; i < lines.length; i++) {
                String line = lines[i];
                if (line.trim().isEmpty()) continue;
                String[] parts = line.split("\\|", 4);
                String cat, date, fav, text;
                if (parts.length >= 4) { cat = parts[0]; date = parts[1]; fav = parts[2]; text = parts[3]; }
                else {
                    String[] oldParts = line.split("\\|", 3);
                    cat = oldParts.length > 0 ? oldParts[0] : "Saved";
                    date = oldParts.length > 1 ? oldParts[1] : "";
                    fav = "0";
                    text = oldParts.length > 2 ? oldParts[2] : line;
                }
                LinearLayout c = card();
                c.addView(tv((fav.equals("1") ? "★ " : "") + cat + " · " + date, 14, Color.rgb(255,217,167), Typeface.BOLD));
                c.addView(tv(text, 16, TEXT, Typeface.NORMAL));
                Button copy = outline("Copy"); copy.setOnClickListener(v -> copy(text)); c.addView(copy);
                if (!fav.equals("1")) { Button star = outline("Favorite"); star.setOnClickListener(v -> { saveItem("Favorite", text, true); showSaved(); }); c.addView(star); }
                Button del = outline("Delete"); final String removeLine = line; del.setOnClickListener(v -> { deleteSavedLine(removeLine); showSaved(); }); c.addView(del);
            }
        }
        Button clear = outline("Clear Saved Repairs"); clear.setOnClickListener(v -> { prefs.edit().remove("saved").apply(); showSaved(); }); root.addView(clear);
        nav();
    }

    private void deleteSavedLine(String target) {
        String data = prefs.getString("saved", "");
        StringBuilder kept = new StringBuilder();
        boolean removed = false;
        for (String line : data.split("\n")) {
            if (!removed && line.equals(target)) { removed = true; continue; }
            if (!line.trim().isEmpty()) kept.append(line).append("\n");
        }
        prefs.edit().putString("saved", kept.toString()).apply();
        toast("Deleted.");
    }

    private void showProfile() {
        currentScreen = "profile";
        header("Private Profile");
        addResult("Pressure Pattern", prefs.getString("pattern", "Not selected yet."));
        addResult("Privacy", "ToneHarbor stores entries locally on your device. No account, no cloud sync, no external sharing is included in this release.");
        addResult("Safety", "ToneHarbor is not therapy, legal advice, diagnosis, crisis care, or emergency support. If there is danger, abuse, threats, self-harm, or an emergency, contact local emergency services or a qualified professional.");
        addResult("Private Lock", prefs.getBoolean("pinEnabled", false) ? "PIN lock is enabled for saved repairs, ledger notes, and private app access." : "PIN lock is available to protect saved repairs, ledger notes, and private app access.");
        addResult("Created By", "ToneHarbor was created by Ulysess Ortiz as a NeuroVerse Works app.");
        Button pin = outline(prefs.getBoolean("pinEnabled", false) ? "Change PIN" : "Set PIN Lock"); pin.setOnClickListener(v -> showPinSetup()); root.addView(pin);
        if (prefs.getBoolean("pinEnabled", false)) { Button removePin = outline("Remove PIN Lock"); removePin.setOnClickListener(v -> disablePin()); root.addView(removePin); }
        Button edit = outline("Edit Pressure Pattern"); edit.setOnClickListener(v -> showPattern()); root.addView(edit);
        Button reset = outline("Reset Private Setup"); reset.setOnClickListener(v -> { prefs.edit().clear().apply(); showWelcome(); }); root.addView(reset);
        nav();
    }

    @Override public void onBackPressed() {
        if (currentScreen.equals("unlock")) super.onBackPressed();
        else if (currentScreen.equals("promise") || currentScreen.equals("pattern")) showWelcome();
        else if (!currentScreen.equals("home") && !currentScreen.equals("welcome")) showHome();
        else super.onBackPressed();
    }
}
