# ToneHarbor V3.0 LiveReady Legacy Edition

ToneHarbor is a private native Android repair and regulation app for tone, pressure, conflict, and steady communication.

This V3 package is a presentation-and-polish release only. It preserves the working app foundation and improves the user experience around existing flows.

## Preserved foundation

- Onboarding
- Command Deck
- Tone Check
- Repair Builder
- Pressure Valve
- Daily Ledger
- Saved Repairs
- Private Profile
- PIN lock
- Copy/save behavior
- Favorite saved phrases
- Weekly summary
- Local-only storage
- Adaptive icon
- GitHub ZIP workflow

## V3 improvements

- More refined Command Deck presentation
- Quick Copy row on Home
- Use This Now cards for immediate copy/save/favorite actions
- Saved Repairs top steady lines section
- Weekly Insight card
- Private Lock wording polish
- Store-ready ownership line
- Integrity audit notes

## Boundaries

No AI, cloud, login, partner mode, subscriptions, social features, or major rebuild were added.
