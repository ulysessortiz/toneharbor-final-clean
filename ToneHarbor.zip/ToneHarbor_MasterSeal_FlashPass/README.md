# ToneHarbor

Private native Android repair and regulation app for tone, pressure, conflict, and steady communication.

## Release state

ToneHarbor Final Legacy Release preserves the working native app while applying the final official polish pass.

Included:
- Native Android app
- No WebView
- Local-only storage
- Onboarding
- Command Deck
- Tone Check
- Repair Builder
- Pressure Valve
- Daily Ledger
- Saved Repairs
- Private Profile
- Copy-to-clipboard support
- Custom launcher icon
- Bottom-safe navigation spacing

## Build

Use GitHub Actions with the clean ZIP workflow or build locally with:

```bash
gradle :app:assembleDebug --stacktrace
```

## Smoke test

Install the APK and confirm:
1. App opens.
2. Welcome/entry works.
3. Onboarding reaches Command Deck.
4. Home buttons respond.
5. Tone Check reaches result.
6. Repair Builder reaches result.
7. Pressure tools open and copy.
8. Ledger selections save.
9. Saved Repairs copy and clear.
10. Private Profile opens and reset works.
