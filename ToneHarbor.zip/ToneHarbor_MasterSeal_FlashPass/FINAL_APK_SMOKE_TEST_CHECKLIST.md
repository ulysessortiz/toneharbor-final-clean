# Final APK Smoke Test Checklist

Run this after installing the APK built from this exact package.

## Install and identity

- [ ] APK installs without warning beyond normal Android unknown-source prompt.
- [ ] Launcher shows ToneHarbor app name.
- [ ] Launcher icon is custom ToneHarbor icon, not generic Android placeholder.
- [ ] App opens without crash.
- [ ] No visible `Delilah Rescue`, `V1.0-G`, `prototype`, `template`, or `coming soon` wording.

## First door

- [ ] Welcome opens if setup is fresh.
- [ ] Enter ToneHarbor opens Private Promise.
- [ ] Continue opens Pressure Pattern.
- [ ] Selecting a pressure pattern opens Command Deck.
- [ ] Returning to app keeps setup saved.

## Core navigation

- [ ] Home opens Command Deck.
- [ ] Tone opens Tone Check.
- [ ] Repair opens Repair Builder.
- [ ] Pressure opens Pressure Valve.
- [ ] Ledger opens Daily Ledger.
- [ ] Bottom nav buttons remain above Android system nav bar.
- [ ] Text remains readable and not swallowed at the bottom.

## Core actions

- [ ] Before It Breaks opens.
- [ ] Tone Check completes to a result.
- [ ] Repair Builder completes to a result.
- [ ] Pressure Valve tool opens and copy works.
- [ ] Save Repair stores phrase.
- [ ] View Saved Repairs shows saved phrase.
- [ ] Daily Ledger accepts selections and saves.
- [ ] Private Profile opens and shows privacy/safety notes.

## Lock criteria

Lock as ToneHarbor Final Legacy Candidate only if every item above passes on the phone.
