# ToneHarbor Smoke Test Checklist

- [ ] Install APK.
- [ ] App icon appears as ToneHarbor, not Android default.
- [ ] App opens.
- [ ] Enter ToneHarbor works.
- [ ] Private Promise opens.
- [ ] Pressure Pattern selection opens Command Deck.
- [ ] Home state buttons respond.
- [ ] Before It Breaks opens and Copy works.
- [ ] Tone Check completes all steps and shows repair path.
- [ ] Repair Builder completes and Copy works.
- [ ] Pressure Valve tools open, copy, and save.
- [ ] Daily Ledger selections respond and Save works.
- [ ] Saved Repairs opens, copies, and clears.
- [ ] Private Profile opens.
- [ ] Reset Private Setup returns to Welcome.
- [ ] Bottom navigation is readable and not swallowed by system navigation.
- [ ] No old wording appears in the app.
