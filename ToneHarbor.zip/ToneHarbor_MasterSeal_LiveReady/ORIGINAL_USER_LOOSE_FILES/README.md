# ToneHarbor V1.0-F Clean Native Rebuild

This is the clean emergency rebuild after the WebView APK path failed phone testing.

## Guardian status

- Native-first Android app
- No WebView
- No HTML / JavaScript click layer
- No ZIP-routing workflow
- No old package dependency
- Direct GitHub Actions Android build
- First button is a native Android Button with a real OnClickListener

## App identity

**ToneHarbor**  
**Repair the moment before distance grows.**

A private repair and regulation app for men centered on tone impact, pressure regulation, responsibility, and repair.

## Included native features

- Premium native welcome screen
- Private Promise screen
- Pressure Pattern onboarding
- Home Command Deck
- Before It Breaks emergency flow
- Tone Check flow
- Repair Builder flow
- Pressure Valve tools
- Daily Ledger local save
- Saved Repair Library
- Private Profile
- Local-only SharedPreferences storage
- Native clipboard copy
- Native buttons and routing

## GitHub build

Upload the contents of this folder into a clean GitHub repository. Do not upload this ZIP as the project root.

Then go to **Actions** and run:

`Build ToneHarbor Native APK`

Artifact:

`ToneHarbor-V1.0-F-clean-native-rebuild-apk`

## First phone smoke test

1. Install APK.
2. Open ToneHarbor.
3. Tap **Enter ToneHarbor**.
4. Confirm Private Promise opens.
5. Tap Continue.
6. Select a pressure pattern.
7. Confirm Home opens.
8. Test bottom navigation.
9. Test Tone Check result.
10. Test Copy and Save.

If step 3 fails, the native rebuild fails. No excuses.
