# Clean Rebuild Audit

## Failed path retired

The previous WebView-based launch candidate displayed beautifully but failed phone testing because the first interaction did not advance on-device. The GitHub workflow then became tangled by building from ZIP files inside the repo.

## V1.0-F repair principle

This build removes the entire failure surface:

- No WebView
- No JavaScript startup dependency
- No document click delegation
- No HTML files
- No ZIP search in workflow
- No old D/E package confusion

## Native route

The first screen button is created in `MainActivity.java` and uses:

`enter.setOnClickListener(v -> showPromise());`

That is the root recovery.
