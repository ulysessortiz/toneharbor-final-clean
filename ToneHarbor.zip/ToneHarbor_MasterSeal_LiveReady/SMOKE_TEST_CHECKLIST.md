# ToneHarbor Master Seal Phone Smoke Test Checklist

## Install and entry

- [ ] APK installs on Android.
- [ ] App opens without crash.
- [ ] Welcome screen is visible and scroll-safe.
- [ ] Enter ToneHarbor opens Private Promise.
- [ ] Open Command Deck opens the Home screen.
- [ ] Continue opens Pressure Pattern setup.
- [ ] Selecting a pressure pattern opens Command Deck.

## Command Deck

- [ ] State buttons show responses.
- [ ] Before It Breaks opens.
- [ ] Copy Next Sentence copies text.
- [ ] Quick Actions route correctly.
- [ ] View Saved Repairs opens.
- [ ] Private Profile opens.

## Tone Check

- [ ] What happened selection advances.
- [ ] Inside state selection advances.
- [ ] Landing selection advances.
- [ ] Result page displays Possible Truth, Possible Impact, Responsibility Line, Repair Sentence, Next Move.
- [ ] Copy Text Version works.
- [ ] Save Repair works.
- [ ] Start Over works.

## Repair Builder

- [ ] Repair type selection advances.
- [ ] Repair style selection advances.
- [ ] Output displays Use This, Do Not Add, Better Next Action.
- [ ] Copy works.
- [ ] Save Repair works.
- [ ] Build Another works.

## Pressure Valve

- [ ] Do Not Send That Yet opens.
- [ ] 60-Second Reset opens.
- [ ] Tone Softener opens.
- [ ] Focus Mode opens.
- [ ] I Need Space Without Punishing opens.
- [ ] After Work Decompression opens.
- [ ] Copy works in each tool.
- [ ] Save works in each tool.

## Ledger and saved data

- [ ] Ledger category buttons select and toast.
- [ ] Honest note accepts typing.
- [ ] Save Today's Ledger saves without crash.
- [ ] Saved repairs persist after app close and reopen.
- [ ] Clear Saved Repairs works.

## Private Profile

- [ ] Pressure Pattern displays.
- [ ] Privacy note displays.
- [ ] Safety note displays.
- [ ] Edit Pressure Pattern works.
- [ ] Reset Private Setup works.

## Seal requirement

- [ ] No dead buttons.
- [ ] No WebView behavior.
- [ ] No test/prototype wording in the active app.
- [ ] No Guardian/Delilah/backend wording in the active app.
- [ ] Text remains readable on phone.
