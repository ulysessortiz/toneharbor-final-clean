package com.toneharbor.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(5, 7, 9);
    private final int CARD = Color.rgb(18, 22, 26);
    private final int CARD2 = Color.rgb(24, 29, 34);
    private final int TEXT = Color.rgb(246, 239, 225);
    private final int MUTED = Color.rgb(178, 174, 166);
    private final int EMBER = Color.rgb(232, 166, 84);
    private final int LINE = Color.rgb(80, 69, 55);

    private SharedPreferences prefs;
    private LinearLayout root;
    private String currentScreen = "home";
    private String toneWhat = "", toneInside = "", toneLand = "";
    private String repairType = "", repairStyle = "";
    private String ledgerRelationship = "Not selected", ledgerHome = "Not selected", ledgerBody = "Not selected", ledgerMoney = "Not selected", ledgerPresence = "Not selected";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("toneharbor", MODE_PRIVATE);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        if (!prefs.getBoolean("onboarded", false)) showWelcome(); else showHome();
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }

    private void base() {
        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(BG);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(22), dp(20), dp(18));
        scroll.addView(root, new ScrollView.LayoutParams(ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));
        frame.addView(scroll, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(frame);
    }

    private TextView tv(String s, int sp, int color, int style) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setTypeface(Typeface.DEFAULT, style);
        t.setLineSpacing(dp(2), 1.0f);
        t.setPadding(0, dp(4), 0, dp(4));
        return t;
    }

    private void space(int h) { Space s = new Space(this); root.addView(s, new LinearLayout.LayoutParams(1, dp(h))); }

    private GradientDrawable bg(int color, int strokeColor, int stroke, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radius));
        if (stroke > 0) g.setStroke(dp(stroke), strokeColor);
        return g;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(18), dp(16), dp(18), dp(16));
        c.setBackground(bg(CARD, LINE, 1, 24));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(8), 0, dp(8));
        root.addView(c, lp);
        return c;
    }

    private LinearLayout innerCard(LinearLayout parent) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(14), dp(12), dp(14), dp(12));
        c.setBackground(bg(CARD2, LINE, 1, 18));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(6), 0, dp(6));
        parent.addView(c, lp);
        return c;
    }

    private Button btn(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(16);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(Color.rgb(24, 16, 8));
        b.setBackground(bg(EMBER, EMBER, 0, 22));
        b.setPadding(dp(8), dp(12), dp(8), dp(12));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(8), 0, dp(8));
        b.setLayoutParams(lp);
        return b;
    }

    private Button outline(String text) {
        Button b = btn(text);
        b.setTextColor(TEXT);
        b.setBackground(bg(CARD2, LINE, 1, 20));
        return b;
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    private void copy(String s) {
        ClipboardManager cm = (ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("ToneHarbor", s));
        toast("Copied.");
    }

    private void saveItem(String cat, String text) {
        String old = prefs.getString("saved", "");
        String date = new SimpleDateFormat("MMM d, yyyy", Locale.US).format(new Date());
        prefs.edit().putString("saved", old + cat + "|" + date + "|" + text.replace("\n", " ") + "\n").apply();
        toast("Saved to your Harbor.");
    }

    private void addTitle(String title, String sub) {
        root.addView(tv(title, 32, TEXT, Typeface.BOLD));
        if (sub != null && !sub.isEmpty()) root.addView(tv(sub, 16, MUTED, Typeface.NORMAL));
        space(10);
    }

    private void header(String title) {
        base();
        TextView h = tv("ToneHarbor", 14, Color.rgb(255, 217, 167), Typeface.BOLD);
        root.addView(h);
        addTitle(title, "Repair the moment before distance grows.");
    }

    private void nav() {
        LinearLayout n = new LinearLayout(this);
        n.setOrientation(LinearLayout.HORIZONTAL);
        String[] tabs = {"Home", "Tone", "Repair", "Pressure", "Ledger"};
        for (String tab : tabs) {
            Button b = outline(tab);
            b.setTextSize(12);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
            lp.setMargins(dp(2), dp(8), dp(2), dp(8));
            b.setLayoutParams(lp);
            b.setOnClickListener(v -> {
                if (tab.equals("Home")) showHome();
                else if (tab.equals("Tone")) showTone1();
                else if (tab.equals("Repair")) showRepair1();
                else if (tab.equals("Pressure")) showPressure();
                else showLedger();
            });
            n.addView(b);
        }
        root.addView(n);
    }

    private void showWelcome() {
        currentScreen = "welcome";
        base();
        space(18);
        LinearLayout c = card();
        c.addView(tv("PRIVATE REPAIR AND REGULATION", 14, Color.rgb(255,217,167), Typeface.BOLD));
        c.addView(tv("ToneHarbor", 42, TEXT, Typeface.BOLD));
        c.addView(tv("Repair the moment before distance grows.", 18, MUTED, Typeface.NORMAL));
        LinearLayout pill = innerCard(c);
        TextView p = tv("PRESSURE  →  TONE  →  REPAIR", 16, Color.rgb(255,217,167), Typeface.BOLD);
        p.setGravity(Gravity.CENTER);
        pill.addView(p);
        c.addView(tv("Built for the moments when pressure affects your tone, your words, or your next move.", 17, MUTED, Typeface.NORMAL));
        Button enter = btn("Enter ToneHarbor");
        enter.setOnClickListener(v -> showPromise());
        c.addView(enter);
        Button open = outline("Open Command Deck");
        open.setOnClickListener(v -> { prefs.edit().putBoolean("onboarded", true).apply(); showHome(); });
        c.addView(open);
        space(18);
    }

    private void showPromise() {
        currentScreen = "promise";
        header("Private Promise");
        LinearLayout c = card();
        c.addView(tv("No diagnosis. No judgment. No blame machine.", 22, TEXT, Typeface.BOLD));
        c.addView(tv("ToneHarbor helps you pause, understand possible impact, regulate pressure, and choose a steadier next move.", 18, TEXT, Typeface.NORMAL));
        c.addView(tv("It does not decide who is right. It does not replace therapy, legal advice, crisis care, or emergency support.", 15, MUTED, Typeface.NORMAL));
        Button next = btn("Continue");
        next.setOnClickListener(v -> showPattern());
        root.addView(next);
        Button command = outline("Open Command Deck");
        command.setOnClickListener(v -> { prefs.edit().putBoolean("onboarded", true).apply(); showHome(); });
        root.addView(command);
    }

    private void showPattern() {
        currentScreen = "pattern";
        header("Choose your pressure pattern");
        String[] opts = {"I get sharp when focused", "I shut down when overwhelmed", "I explain too much", "I get defensive after apologizing", "I rush people", "I avoid hard talks", "I get jealous or insecure", "I come home empty from work"};
        for (String o : opts) {
            Button b = outline(o);
            b.setOnClickListener(v -> { prefs.edit().putString("pattern", o).putBoolean("onboarded", true).apply(); showHome(); });
            root.addView(b);
        }
    }

    private void showHome() {
        currentScreen = "home";
        header("Command Deck");
        LinearLayout c = card();
        c.addView(tv("Where are you right now?", 20, TEXT, Typeface.BOLD));
        String[] states = {"Calm", "Pressured", "Irritated", "Shut Down", "Distracted", "Guilty", "About to React"};
        for (String s : states) {
            Button b = outline(s);
            b.setOnClickListener(v -> toast(responseForState(s)));
            c.addView(b);
        }
        Button emergency = btn("Before It Breaks");
        emergency.setOnClickListener(v -> showBeforeItBreaks());
        root.addView(emergency);
        LinearLayout q = card();
        q.addView(tv("Quick Actions", 20, TEXT, Typeface.BOLD));
        addAction(q, "Check My Tone", () -> showTone1());
        addAction(q, "Build a Repair", () -> showRepair1());
        addAction(q, "Use Pressure Valve", () -> showPressure());
        addAction(q, "Open Daily Ledger", () -> showLedger());
        LinearLayout line = card();
        line.addView(tv("Today’s Harbor Line", 18, Color.rgb(255,217,167), Typeface.BOLD));
        line.addView(tv(harborLine(), 18, TEXT, Typeface.BOLD));
        Button saved = outline("View Saved Repairs");
        saved.setOnClickListener(v -> showSaved());
        root.addView(saved);
        Button profile = outline("Private Profile");
        profile.setOnClickListener(v -> showProfile());
        root.addView(profile);
        nav();
    }

    private void addAction(LinearLayout parent, String label, final Action a) { Button b = outline(label); b.setOnClickListener(v -> a.run()); parent.addView(b); }
    interface Action { void run(); }

    private String responseForState(String s) {
        if (s.equals("Calm")) return "Steady is easier to protect before pressure rises.";
        if (s.equals("Pressured")) return "Pressure can be real without making the next move sharp.";
        if (s.equals("Irritated")) return "Slow the next sentence before it becomes damage.";
        if (s.equals("Shut Down")) return "Space is allowed. Coldness is not the only way to take it.";
        if (s.equals("Distracted")) return "Presence often begins with one honest pause.";
        if (s.equals("Guilty")) return "Guilt can become repair if you do not turn it into self-attack.";
        return "Do not let the first impulse become the final message.";
    }

    private String harborLine() {
        String pat = prefs.getString("pattern", "");
        if (pat.contains("focused")) return "Focus can make your voice sound colder than your heart.";
        if (pat.contains("defensive")) return "Repair without defending first.";
        if (pat.contains("shut")) return "Take space without going cold.";
        if (pat.contains("home")) return "Do not make your first tone the leftover noise from the day.";
        String[] lines = {"Your state explains the tone. It does not erase the impact.", "Repair faster than pride can harden.", "Say less. Soften more. Own the landing.", "Pressure is real. The next move is still yours.", "Give space without going cold."};
        int i = (int)(System.currentTimeMillis() / 86400000L % lines.length);
        return lines[i];
    }

    private void showBeforeItBreaks() {
        currentScreen = "before";
        header("Before It Breaks");
        LinearLayout c = card();
        c.addView(tv("Pause line", 16, Color.rgb(255,217,167), Typeface.BOLD));
        String pause = "I want to answer better than my stress is letting me.";
        String next = "Give me one second. I’m not leaving the conversation. I’m trying not to make it worse.";
        c.addView(tv(pause, 22, TEXT, Typeface.BOLD));
        c.addView(tv("Drop your shoulders. Breathe out slowly.", 16, MUTED, Typeface.NORMAL));
        c.addView(tv(next, 18, TEXT, Typeface.NORMAL));
        Button copy = btn("Copy Next Sentence");
        copy.setOnClickListener(v -> copy(next));
        c.addView(copy);
        Button pressure = outline("Open Pressure Valve"); pressure.setOnClickListener(v -> showPressure()); c.addView(pressure);
        Button repair = outline("Build a Repair"); repair.setOnClickListener(v -> showRepair1()); c.addView(repair);
        nav();
    }

    private void showTone1() { currentScreen = "tone"; header("Tone Check"); selectList("What happened?", new String[]{"My tone sounded rude", "I interrupted someone", "I snapped", "I got defensive", "I shut down", "I sounded cold", "I rushed the conversation", "I was focused and came off harsh", "Something else"}, s -> { toneWhat = s; showTone2(); }); }
    private void showTone2() { currentScreen = "tone"; header("Tone Check"); selectList("What was happening inside you?", new String[]{"I was focused", "I was overwhelmed", "I was tired", "I was anxious", "I was counting / calculating", "I felt accused", "I wanted space", "I was trying to solve it", "I do not know"}, s -> { toneInside = s; showTone3(); }); }
    private void showTone3() { currentScreen = "tone"; header("Tone Check"); selectList("How did it seem to land?", new String[]{"Dismissive", "Sharp", "Cold", "Impatient", "Controlling", "Unavailable", "Like I did not care", "I am not sure"}, s -> { toneLand = s; showToneResult(); }); }

    interface Pick { void set(String s); }
    private void selectList(String title, String[] opts, Pick pick) { LinearLayout c = card(); c.addView(tv(title, 20, TEXT, Typeface.BOLD)); for (String o : opts) { Button b = outline(o); b.setOnClickListener(v -> pick.set(o)); c.addView(b); } nav(); }

    private void showToneResult() {
        currentScreen = "tone";
        header("Your Repair Path");
        String repair = toneRepair();
        addResult("Possible Truth", "You may have been overloaded, focused, hurt, or defensive. That can explain the reaction without making the impact disappear.");
        addResult("Possible Impact", "It may have landed as " + safeLower(toneLand) + ", distance, or dismissal.");
        addResult("Responsibility Line", "Your state explains the tone. It does not erase the impact.");
        addResult("Repair Sentence", repair);
        addResult("Next Move", "Offer repair once. Give space without punishing. Do not argue your intent first.");
        Button save = btn("Save Repair"); save.setOnClickListener(v -> saveItem("Tone repair", repair)); root.addView(save);
        Button copy = outline("Copy Text Version"); copy.setOnClickListener(v -> copy(repair)); root.addView(copy);
        Button calm = outline("I Need to Calm Down First"); calm.setOnClickListener(v -> showPressure()); root.addView(calm);
        Button again = outline("Start Over"); again.setOnClickListener(v -> showTone1()); root.addView(again);
        nav();
    }

    private String safeLower(String s) { return (s == null || s.length() == 0) ? "unclear" : s.toLowerCase(Locale.US); }
    private void addResult(String label, String text) { LinearLayout c = card(); c.addView(tv(label, 16, Color.rgb(255,217,167), Typeface.BOLD)); c.addView(tv(text, 18, TEXT, Typeface.NORMAL)); }

    private String toneRepair() {
        if (toneInside.contains("counting") || toneWhat.contains("focused")) return "I’m sorry. I got locked into what I was doing and sounded sharper than I meant to. I was not trying to dismiss you, but I understand how it landed.";
        if (toneWhat.contains("defensive")) return "I’m sorry I got defensive. I wanted to explain myself, but I should have acknowledged the impact first.";
        if (toneWhat.contains("shut")) return "I’m sorry I went quiet in a way that felt cold. I needed space, but I should have said that without disappearing.";
        if (toneWhat.contains("interrupted")) return "I’m sorry I interrupted you. I was trying to handle the moment, but I still cut you off and I understand how that could land.";
        return "I’m sorry for how that landed. I may have been pressured, but I still want to own the impact and speak better.";
    }

    private void showRepair1() { currentScreen = "repair"; header("Repair Builder"); selectList("What needs repair?", new String[]{"My tone", "My silence", "My defensiveness", "My impatience", "My jealousy / insecurity", "My distraction", "A broken promise", "Stress spillover"}, s -> { repairType = s; showRepair2(); }); }
    private void showRepair2() { currentScreen = "repair"; header("Repair Builder"); selectList("What style do you need?", new String[]{"Short and simple", "Warm and accountable", "After they left upset", "After I made it worse", "Give space without disappearing"}, s -> { repairStyle = s; showRepairResult(); }); }

    private void showRepairResult() {
        currentScreen = "repair";
        header("Repair Output");
        String msg = repairMsg();
        addResult("Use This", msg);
        addResult("Do Not Add", "Do not add: ‘but I didn’t mean it,’ ‘you always take it wrong,’ ‘I already apologized,’ or ‘fine, forget it.’");
        addResult("Better Next Action", "Give space without going cold. Repair the landing before explaining the intent.");
        Button copy = btn("Copy"); copy.setOnClickListener(v -> copy(msg)); root.addView(copy);
        Button save = outline("Save Repair"); save.setOnClickListener(v -> saveItem("Repair", msg)); root.addView(save);
        Button again = outline("Build Another"); again.setOnClickListener(v -> showRepair1()); root.addView(again);
        nav();
    }

    private String repairMsg() {
        if (repairStyle.contains("left")) return "I’m sorry today turned heavy. I can see how my tone made it harder to receive what I meant. I’ll give you space, and I’m here when you’re ready.";
        if (repairStyle.contains("worse")) return "I’m sorry. I made it worse after the first moment. I do not want to defend that. I want to own it and do better from here.";
        if (repairStyle.contains("space")) return "I need a few minutes to settle so I do not speak worse. I’m not leaving the conversation.";
        if (repairStyle.contains("Warm")) return "I’m sorry for my " + repairType.toLowerCase(Locale.US) + ". I was under pressure, but I still should have handled it softer and clearer.";
        return "I’m sorry for how I handled that. I should have spoken softer.";
    }

    private void showPressure() {
        currentScreen = "pressure";
        header("Pressure Valve");
        String[] tools = {"Do Not Send That Yet", "60-Second Reset", "Tone Softener", "Focus Mode", "I Need Space Without Punishing", "After Work Decompression"};
        for (String tool : tools) { Button b = outline(tool); b.setOnClickListener(v -> showPressureTool(tool)); root.addView(b); }
        nav();
    }

    private void showPressureTool(String tool) {
        currentScreen = "pressure";
        header(tool);
        LinearLayout c = card();
        String text;
        if (tool.startsWith("Do")) text = "Wait 60 seconds. Rewrite for repair, not victory. Safer line: I want to say this better. I’m upset, but I do not want to make it worse.";
        else if (tool.startsWith("60")) text = "Unclench your jaw. Drop your shoulders. Breathe out longer than you breathe in. Say: I can repair without defending first. Choose one next move.";
        else if (tool.startsWith("Tone")) text = "Instead of ‘Wait,’ say: Give me one second, I want to hear you. Instead of ‘I’m busy,’ say: I’m in the middle of something, but you matter.";
        else if (tool.startsWith("Focus")) text = "Give me one second. I’m focused, not ignoring you. I want to hear you. I need one minute to finish this safely.";
        else if (tool.startsWith("I Need")) text = "I need a few minutes to settle so I do not speak worse. I’m not leaving the conversation.";
        else text = "I’m tired, but I’m glad to be home. Give me a minute to land.";
        c.addView(tv(text, 18, TEXT, Typeface.NORMAL));
        Button copy = btn("Copy"); copy.setOnClickListener(v -> copy(text)); c.addView(copy);
        Button save = outline("Save"); save.setOnClickListener(v -> saveItem("Pressure", text)); c.addView(save);
        nav();
    }

    private void showLedger() {
        currentScreen = "ledger";
        header("Daily Ledger");
        LinearLayout c = card();
        c.addView(tv("Private accountability without shame.", 18, TEXT, Typeface.BOLD));
        addLedgerGroup(c, "Relationship", "Did I repair anything I damaged today?", new String[]{"Yes", "Not needed", "I avoided it", "I made it worse", "I need help repairing"}, "relationship");
        addLedgerGroup(c, "Home", "What is one thing I handled without being asked?", new String[]{"Cleaned something", "Paid / checked something", "Followed up", "Helped partner", "Planned food", "Was present", "Not today"}, "home");
        addLedgerGroup(c, "Body", "Did I treat my body like it has to carry me tomorrow?", new String[]{"Water", "Food", "Sleep", "Walk", "Medication", "Less nicotine / alcohol", "Not today"}, "body");
        addLedgerGroup(c, "Money", "Did I face one money truth today?", new String[]{"Counted", "Paid", "Planned", "Asked", "Avoided", "Not needed"}, "money");
        addLedgerGroup(c, "Presence", "Who needed me present today?", new String[]{"Partner", "Child", "Family", "Friend", "Myself", "Pet", "No one today"}, "presence");
        EditText note = new EditText(this);
        note.setHint("One honest line");
        note.setTextColor(TEXT); note.setHintTextColor(MUTED); note.setSingleLine(false); note.setMinLines(2); note.setBackground(bg(CARD2, LINE, 1, 16));
        c.addView(note);
        Button save = btn("Save Today’s Ledger");
        save.setOnClickListener(v -> {
            String old = prefs.getString("ledger", "");
            String date = new SimpleDateFormat("MMM d, yyyy h:mm a", Locale.US).format(new Date());
            String row = date + " | Relationship: " + ledgerRelationship + " | Home: " + ledgerHome + " | Body: " + ledgerBody + " | Money: " + ledgerMoney + " | Presence: " + ledgerPresence + " | Note: " + note.getText().toString() + "\n";
            prefs.edit().putString("ledger", old + row).apply();
            toast("Saved. You faced today honestly.");
        });
        c.addView(save);
        Button saved = outline("View Saved Repairs"); saved.setOnClickListener(v -> showSaved()); root.addView(saved);
        nav();
    }

    private void addLedgerGroup(LinearLayout parent, String title, String prompt, String[] opts, String key) {
        LinearLayout box = innerCard(parent);
        box.addView(tv(title, 16, Color.rgb(255,217,167), Typeface.BOLD));
        box.addView(tv(prompt, 16, TEXT, Typeface.NORMAL));
        for (String opt : opts) {
            Button b = outline(opt);
            b.setOnClickListener(v -> { setLedger(key, opt); toast(title + ": " + opt); });
            box.addView(b);
        }
    }

    private void setLedger(String key, String value) {
        if (key.equals("relationship")) ledgerRelationship = value;
        else if (key.equals("home")) ledgerHome = value;
        else if (key.equals("body")) ledgerBody = value;
        else if (key.equals("money")) ledgerMoney = value;
        else ledgerPresence = value;
    }

    private void showSaved() {
        currentScreen = "saved";
        header("Saved Repairs");
        String data = prefs.getString("saved", "");
        if (data.trim().isEmpty()) addResult("No saved repairs yet", "The right words can be saved when you need them again.");
        else {
            String[] lines = data.split("\n");
            for (String line : lines) {
                if (line.trim().isEmpty()) continue;
                String[] parts = line.split("\\|", 3);
                String cat = parts.length > 0 ? parts[0] : "Saved";
                String date = parts.length > 1 ? parts[1] : "";
                String text = parts.length > 2 ? parts[2] : line;
                LinearLayout c = card();
                c.addView(tv(cat + " · " + date, 14, Color.rgb(255,217,167), Typeface.BOLD));
                c.addView(tv(text, 16, TEXT, Typeface.NORMAL));
                Button copy = outline("Copy"); copy.setOnClickListener(v -> copy(text)); c.addView(copy);
            }
        }
        Button clear = outline("Clear Saved Repairs"); clear.setOnClickListener(v -> { prefs.edit().remove("saved").apply(); showSaved(); }); root.addView(clear);
        nav();
    }

    private void showProfile() {
        currentScreen = "profile";
        header("Private Profile");
        addResult("Pressure Pattern", prefs.getString("pattern", "Not selected yet."));
        addResult("Privacy", "ToneHarbor stores entries locally on your device. No account, no cloud sync, no external sharing is included in this release.");
        addResult("Safety", "ToneHarbor is not therapy, legal advice, diagnosis, crisis care, or emergency support. If there is danger, abuse, threats, self-harm, or an emergency, contact local emergency services or a qualified professional.");
        Button edit = outline("Edit Pressure Pattern"); edit.setOnClickListener(v -> showPattern()); root.addView(edit);
        Button reset = outline("Reset Private Setup"); reset.setOnClickListener(v -> { prefs.edit().clear().apply(); showWelcome(); }); root.addView(reset);
        nav();
    }

    @Override public void onBackPressed() {
        if (currentScreen.equals("promise") || currentScreen.equals("pattern")) showWelcome();
        else if (!currentScreen.equals("home") && !currentScreen.equals("welcome")) showHome();
        else super.onBackPressed();
    }
}
