# ToneHarbor Master Seal Live-Ready Native Repair

ToneHarbor is a private repair and regulation Android app for men centered on tone impact, pressure regulation, accountability, and steadier repair language.

## Build identity

- Native Android Java app
- Package: `com.toneharbor.app`
- App label: `ToneHarbor`
- Local-only storage through SharedPreferences
- Native copy-to-clipboard support
- No WebView
- No HTML shell
- No JavaScript click layer
- No login
- No cloud sync
- No external sharing

## What this repair fixes

This package treats the user's loose files as the protected source material and repairs the actual failure class:

1. The first screen could get stuck or behave fragile on-device.
2. A later entry fix could allow access but destabilize flow state, back behavior, and polish.
3. Active app language still carried setup/test wording that did not belong in a flagship user experience.

## Included app sections

- Welcome / Private Promise
- Pressure Pattern setup
- Command Deck
- Before It Breaks
- Tone Check / Tone Landing Detector
- Repair Builder
- Pressure Valve tools
- Daily Ledger
- Saved Repair Library
- Private Profile

## GitHub build

Upload the contents of this folder into a clean GitHub repository. Do not upload this ZIP as a nested ZIP inside the repository.

Then run:

`Actions → Build ToneHarbor Native APK`

Artifact:

`ToneHarbor-master-seal-live-ready-apk`

## Required first phone test

1. Install APK.
2. Open ToneHarbor.
3. Tap Enter ToneHarbor.
4. Confirm Private Promise opens.
5. Tap Continue.
6. Select a pressure pattern.
7. Confirm Command Deck opens.
8. Test bottom navigation.
9. Complete Tone Check.
10. Copy a repair sentence.
11. Save a repair sentence.
12. Open Saved Repairs and copy the saved item.
13. Open Pressure Valve and test each tool.
14. Save Daily Ledger.
15. Open Private Profile.
16. Reset Private Setup and confirm welcome returns.

No visual approval is final until this phone smoke test passes.
