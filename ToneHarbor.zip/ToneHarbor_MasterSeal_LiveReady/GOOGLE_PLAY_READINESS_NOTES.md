# Google Play Readiness Notes

## Ready now

- Native Android project structure
- Application ID: `com.toneharbor.app`
- App label: `ToneHarbor`
- Privacy and safety notes inside app
- Local-only storage model
- No account, no cloud sync, no external sharing
- No WebView dependency
- Debug APK build workflow

## Still required before Play Store submission

- Real Android phone smoke test
- Signed release build or Android App Bundle
- Store icon and Play feature graphic
- Privacy Policy page matching local-only storage claim
- Google Play Data Safety answers
- Content rating questionnaire
- Release notes
- Final listing copy review

## Suggested short description

Private repair and regulation for pressure, tone, conflict, and responsibility.

## Suggested long description

ToneHarbor helps men pause before pressure becomes distance. Use guided tone checks, repair messages, pressure reset tools, focus-mode phrases, and a private daily ledger to handle tone, silence, defensiveness, conflict, and responsibility with more steadiness.

ToneHarbor does not diagnose, judge, or decide who is right. It helps you understand possible impact, regulate pressure, and choose a safer next move.
