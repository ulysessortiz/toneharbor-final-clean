# ToneHarbor V2.0 Repair Intelligence Upgrade

ToneHarbor V2.0 is an intentional upgrade after the V1 Final Legacy APK Candidate. It preserves the working native Android structure while sharpening repair intelligence, saved phrase usefulness, weekly accountability visibility, and private PIN security.

## Boundary

- No new core structure
- No AI backend
- No partner mode
- No cloud sync
- No social/community features
- No subscription layer
- No WebView

## V2 upgrades

- Smarter Tone Landing Detector results
- Expanded Repair Builder library
- Save as Favorite actions
- Saved Repairs copy / favorite / delete controls
- Weekly Ledger summary
- Private PIN lock
- VersionCode 2 / VersionName 2.0
- Existing adaptive icon and status/nav bar safety preserved

## GitHub build

Upload this ZIP as `ToneHarbor.zip` to the clean repo and run:

`Build ToneHarbor Clean APK`

The workflow should unzip the package, locate `settings.gradle`, verify active app source only, and build the debug APK artifact.

## V2.0-GP1 Store-Ready Refinement
This package adds a focused store-readiness refinement without altering the working foundation. It improves perceived intelligence through state-reset result cards, clearer Tone Check steps, premium result summaries, and safer GitHub ZIP filename handling.
