# ToneHarbor V2.0 Final APK Smoke Test Checklist

## Required pass gates

1. App installs as ToneHarbor.
2. App opens without crash.
3. Onboarding works for new install.
4. Command Deck opens.
5. Tone Landing Detector completes all steps.
6. Tone result is more specific than V1 and includes copy/save/favorite.
7. Repair Builder completes all steps.
8. Repair output can be copied, saved, and favorited.
9. Pressure Valve opens and pressure lines can be copied/saved/favorited.
10. Daily Ledger saves an entry.
11. Weekly Summary count updates after saved/ledger actions.
12. Saved Repairs shows saved items.
13. Saved Repairs copy works.
14. Favorite works.
15. Delete works.
16. Private Profile opens.
17. Set PIN Lock works with matching 4+ digit PIN.
18. Closing and reopening app shows unlock screen when PIN is enabled.
19. Wrong PIN refuses access.
20. Correct PIN unlocks app.
21. Remove PIN Lock works.
22. Bottom navigation remains usable.
23. No Delilah Rescue / V1.0-G / prototype / template / coming soon wording appears in active app.

If any one required gate fails, patch only that specific defect.
